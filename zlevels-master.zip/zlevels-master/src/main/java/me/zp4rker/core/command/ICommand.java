package me.zp4rker.core.command;

/**
 * @author ZP4RKER
 */
public interface ICommand {}
