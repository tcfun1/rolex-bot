package me.zp4rker.zlevels.config;

/**
 * @author ZP4RKER
 */
class ConfigException extends Exception {

    ConfigException(Throwable throwable) {
        super(throwable);
    }

}
